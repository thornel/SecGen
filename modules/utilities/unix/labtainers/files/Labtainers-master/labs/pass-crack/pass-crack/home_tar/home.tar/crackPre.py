#!/usr/bin/env python
# --------------------------------------------------------------------------
# File: crackPre.py
# --------------------------------------------------------------------------
# Description: A simple password cracking program that assumes the existence
#              of a set of files that contain a sorting of possible passwords
#              based on those passwords that hash to the same first two hex
#              digits.
#
# Usage:
#     python crackPre.py passwordfile directory
#
#     The 'passwordfile' must be in the htpasswd format with the SHA hash.
#     The 'directory' needs to contain the necessary files that were
#        pre-sorted by precalc.py.
#
# Created: 2014-09-22 (P. Clark)
#
# Modifications:
# --------------------------------------------------------------------------

import sys
from array import array
import base64
import hashlib
import os
from time import time

# Make sure I was given all the inputs that I need (and no more)
if (len(sys.argv) != 3):
    print "Invalid syntax"
    sys.exit(1)

# open the password file and read in the contents
fd = open(sys.argv[1], 'r')
passes = fd.readlines()
fd.close()

# make sure the input directory exists
dirname = sys.argv[2]
if not os.path.isdir(dirname):
    print "Input directory does not exist"
    sys.exit(1)

# Calc the number of lines in the password file
num_passes = len(passes)


words_tried = 0
found = 0
print "-----------------------------"
print "Cracking..."
print "-----------------------------"
start_time = time()
for line in passes:
    # Extract user name from password entry
    name_index = line.find(':')
    name = line[:name_index]
  
    # Verify the hash is a SHA hash
    sha_index = line.find('{SHA}')
    if sha_index <= 0:
        print name + " entry using unrecognized hash function."

    # Get the hash and determine the file name
    pass_hash = line[sha_index+5:].strip('\n')
    filename = pass_hash[0:2]

    # replace '/' if it exists in the filename (confuses OS)
    for i in range(0, 2):
        if filename[i] == '/':
            filename = filename[0:i] + '-' + filename[i+1:]
    
    # Open the file
    try:
        fd = open(dirname + '/' + filename)
    except:
        print name + ": no stored password."
        continue

    # read in the possible passwords
    words = fd.readlines()
       
    # start hashing them
    num_words = len(words)
    for word in words:
        words_tried = words_tried + 1
        word = word.strip('\n')
        hash = base64.b64encode(hashlib.sha1(word).digest())
        if hash == pass_hash:
            found = found + 1
            print name + " : password = \"" + word + "\""
            continue
    fd.close()
    
stop_time = time()
total_time = stop_time - start_time
            
# Display statistics at the end
print "-----------------------------"
print "Found " + str(found) + " out of " + str(num_passes) + " passwords."
sys.stdout.write("Processed " + str(words_tried) + " words in ")
print str(round(total_time,3)) + " seconds."

