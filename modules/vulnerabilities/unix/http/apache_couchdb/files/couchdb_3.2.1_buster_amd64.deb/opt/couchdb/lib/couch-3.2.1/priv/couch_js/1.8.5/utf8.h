// Licensed under the Apache License, Version 2.0 (the "License"); you may not
// use this file except in compliance with the License. You may obtain a copy of
// the License at
//
//   http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
// WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
// License for the specific language governing permissions and limitations under
// the License.

#ifndef COUCH_JS_UTF_8_H
#define COUCH_JS_UTF_8_H

char* enc_string(JSContext* cx, jsval arg, size_t* buflen);
JSString* dec_string(JSContext* cx, const char* buf, size_t buflen);

#endif
