priv/couch_ejson_compare/couch_ejson_compare.o: \
 priv/couch_ejson_compare/couch_ejson_compare.c \
 /usr/lib/erlang/erts-9.3.3.15/include/erl_nif.h \
 /usr/lib/erlang/erts-9.3.3.15/include/erl_drv_nif.h \
 /usr/lib/erlang/erts-9.3.3.15/include/erl_int_sizes_config.h \
 /usr/lib/erlang/erts-9.3.3.15/include/erl_nif_api_funcs.h
