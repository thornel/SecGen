/*
 * %CopyrightBegin%
 * 
 * Copyright Ericsson AB 2001-2016. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * %CopyrightEnd%
 *

 */

#ifndef _EI_DECODE_TERM_H
#define _EI_DECODE_TERM_H

/* Returns 1 if term is decoded, 0 if term is OK, but not decoded here
   and -1 if something is wrong.
   ONLY changes index if term is decoded (return value 1)! */

int ei_decode_ei_term(const char* buf, int* index, ei_term* term);

#endif /* _EI_DECODE_TERM_H */
